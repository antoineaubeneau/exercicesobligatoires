function removeBg() {
    const elems = document.querySelectorAll(".text-bg-success");

    [].forEach.call(elems, function (el) {
        el.classList.remove("text-bg-success");
    });
}

function getAll() {
    fetch('https://swapi.dev/api/people/').then((data) => data.json()).then((data) => {
        let html = '';
        html += '<tr>';
        html += '<th>Nom des dix premiers personnages : </th>';
        html += '</tr>';
        for (var i = 0; i < 10; i++) {
            const responsedata = data.results[i];
            html += '<tr>';
            html += '<td>' + '<br>' + responsedata["name"] + '  ' + '</td>';
            html += '</tr>';
        }
        document.getElementById('result').innerHTML = html;
    });
    removeBg();
    document.getElementById('Tous').className = 'btn btn-outline-warning btnShow text-bg-success';
}

function getCharacter(index) {
    fetch(`https://swapi.dev/api/people/${index}`).then((data) => data.json()).then((data) => {
        const responsename = data.name;
        const responseheight = data.height;
        const responsemass = data.mass;
        const responsefilms = data.films;
        let html = '';
        html += '<tr>';
        html += '<th>Nom : </th>';
        html += '<td>' + responsename + '  ' + '</td>';
        html += '</tr>';
        html += '<tr>';
        html += '<br>';
        html += '<th>Taille : </th>';
        html += '<td>' + responseheight + ' cm ' + '</td>';
        html += '</tr>';
        html += '<br>';
        html += '<tr>';
        html += '<th>Poids : </th>';
        html += '<td>' + responsemass + ' kg ' + '</td>';
        html += '</tr>';
        html += '<br>';
        html += '<tr>';
        html += '<th>Nom des films : </th>';
        html += '<td>' + responsefilms + '  ' + '</td>';
        html += '</tr>';
        document.getElementById('result').innerHTML = html;
    })
    removeBg();
    document.getElementById(index).className = 'btn btn-outline-warning btnShow text-bg-success';
}


function getRandom() {
    const rand = Math.floor(Math.random() * 82) + 1;
    fetch(`https://swapi.dev/api/people/${rand}`).then((data) => data.json()).then((data) => {
        const responsename = data.name;
        const responseheight = data.height;
        const responsemass = data.mass;
        const responsefilms = data.films;
        let html = '';
        html += '<tr>';
        html += '<th>Nom : </th>';
        html += '<td>' + responsename + '  ' + '</td>';
        html += '</tr>';
        html += '<tr>';
        html += '<br>';
        html += '<th>Taille : </th>';
        html += '<td>' + responseheight + ' cm ' + '</td>';
        html += '</tr>';
        html += '<br>';
        html += '<tr>';
        html += '<th>Poids : </th>';
        html += '<td>' + responsemass + ' kg ' + '</td>';
        html += '</tr>';
        html += '<br>';
        html += '<tr>';
        html += '<th>Nom des films : </th>';
        html += '<td>' + responsefilms + '  ' + '</td>';
        html += '</tr>';
        document.getElementById('result').innerHTML = html;
    });
    removeBg();
    document.getElementById('Random').className = 'btn btn-outline-warning btnShow text-bg-success';
}
