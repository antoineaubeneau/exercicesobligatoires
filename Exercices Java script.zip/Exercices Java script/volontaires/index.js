const body = document.body;


const inputText = document.createElement('input');
inputText.type = 'text';
inputText.className = "form-control w-25";
inputText.placeholder = "Prénom";

const div = document.createElement('div');
div.class = "input-group mb-3 container"

div.appendChild(inputText);
body.appendChild(div);

const ul = document.createElement('ul');
ul.className = 'list-group';
div.appendChild(ul);

const addPrenom = document.createElement('button');
addPrenom.type = 'button';
addPrenom.className = 'btn btn-primary';
addPrenom.id = 'button-addon2';
addPrenom.innerHTML = 'Ajouter un prénom ';

div.appendChild(addPrenom);

function getRandomInt(max) {
    return Math.floor(Math.random() * max);
}

const namesList = JSON.parse(localStorage.getItem('names')) || [];

console.log('namesList', namesList);

if (namesList) {
    for (i = 0; i < namesList.length; i++) {
        addname(namesList[i].name, namesList[i].checked);
    }
}

function addname(name, checked = false) {
    const li = document.createElement('li');
    const removeName = document.createElement('button');
    removeName.type = 'button';
    removeName.className = 'btn btn-danger btn-sm';
    removeName.id = 'button-addon2';
    removeName.innerHTML = 'X';
    removeName.onclick = () => removeFromList(name);
    div.appendChild(removeName);
    li.innerHTML = name;
    li.id = name;
    li.className = 'list-group-item w-25 d-flex justify-content-between';
    li.appendChild(removeName);
    ul.appendChild(li);
}

function removeFromList(name) {
    const removedName = document.getElementById(name);
    ul.removeChild(removedName)
    const index = namesList.findIndex((value) => value.name === name);
    namesList.splice(index, 1);
    localStorage.setItem('names', JSON.stringify(namesList));
}


addPrenom.onclick = function () {
    if (inputText.value !== '') {
        namesList.push({ name: inputText.value, checked: false });
        addname(inputText.value);
        inputText.value = '';
    }
    localStorage.setItem('names', JSON.stringify(namesList));
}

const choicePrenom = document.createElement('button');
choicePrenom.type = 'button';
choicePrenom.className = 'btn btn-primary';
choicePrenom.id = 'button-addon2';
choicePrenom.innerHTML = 'Choisir un prénom ';

const choiceDiv = document.createElement('div');
body.appendChild(choiceDiv);

div.appendChild(choicePrenom);

choicePrenom.onclick = function () {
    let rand = getRandomInt(namesList.length);
    const newList = namesList.filter((value) => !value.checked);

    if (!(newList.length === 0)) {
        while (namesList[rand].checked === true) {
            rand = getRandomInt(namesList.length);
        }
        document.getElementById(namesList[rand].name).className = 'list-group-item text-bg-success w-25 d-flex justify-content-between'
        namesList[rand].checked = true;
        choiceDiv.innerText = 'Heureux perdant : ' + namesList[rand].name;
    } else {
        for (i = 0; i < namesList.length; i++) {
            namesList[i].checked = false;
            document.getElementById(namesList[i].name).className = 'list-group-item w-25 d-flex justify-content-between';
        }
        namesList[rand].checked = true;
        document.getElementById(namesList[rand].name).className = 'list-group-item text-bg-success w-25 d-flex justify-content-between';
        choiceDiv.innerText = 'Heureux perdant : ' + namesList[rand].name;
    }
}



